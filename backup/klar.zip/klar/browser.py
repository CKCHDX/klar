#!/usr/bin/env python3
"""
Klar 2.0 Revolutionary Browser - FIXED for EnhancedSwedishCrawler
Works with your exact file structure and class names
"""

import sys
import os
import json
import asyncio
import time
from PyQt5.QtWidgets import QApplication, QMainWindow, QToolBar, QAction, QStatusBar
from PyQt5.QtWebEngineWidgets import QWebEngineView
from PyQt5.QtWebChannel import QWebChannel
from PyQt5.QtCore import QObject, pyqtSignal, pyqtSlot, QUrl, QThread, Qt
from PyQt5.QtGui import QIcon
from qasync import QEventLoop

# Import existing components with CORRECT class names
from crawler import EnhancedSwedishCrawler  # ✅ FIXED - Your actual class name
from parser import parse_html
from indexer import SuperFastBM25Indexer  # ✅ Your enhanced indexer

# Try to import revolutionary algorithms
try:
    from dossna_2 import DOSSNA_2_Engine, SwedishSearchContext
    from asi_2 import ASI_2_Index
    REVOLUTIONARY_MODE = True
    print("🚀 Revolutionary DOSSNA 2.0 + ASI 2.0 + SVEN + THOR + LOKI loaded!")
except ImportError as e:
    REVOLUTIONARY_MODE = False
    print(f"⚡ Enhanced mode (Revolutionary algorithms not found): {e}")

def resource_path(relative_path):
    """Get resource path for PyInstaller compatibility"""
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

def load_domain_metadata():
    """Load domain metadata with enhanced error handling"""
    
    domain_files = ["domains.json", "revolutionary-domains.json"]
    
    for domain_file in domain_files:
        try:
            path = resource_path(domain_file)
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
                print(f"✅ Loaded {domain_file}")
                
                # Handle revolutionary domain format if present
                if "revolutionary_swedish_domains" in data:
                    # Convert to simple format your crawler expects
                    simplified = {}
                    for tier_name, tier_data in data["revolutionary_swedish_domains"].items():
                        if isinstance(tier_data, dict):
                            for category, category_data in tier_data.items():
                                if isinstance(category_data, dict):
                                    for domain, domain_info in category_data.items():
                                        if isinstance(domain_info, dict) and 'keywords' in domain_info:
                                            simplified[domain] = domain_info['keywords']
                    return simplified
                
                return data
                
        except (FileNotFoundError, json.JSONDecodeError) as e:
            print(f"⚠️ Could not load {domain_file}: {e}")
            continue
    
    # Ultimate fallback - basic Swedish domains
    print("⚠️ Using fallback Swedish domains")
    return {
        "svt.se": ["nyheter", "politik", "sport", "kultur"],
        "skatteverket.se": ["skatt", "deklaration", "moms", "tjänster"], 
        "blocket.se": ["köp", "sälj", "bil", "bostad", "elektronik"],
        "stockholm.se": ["kommun", "tjänster", "invånare", "kontakt"],
        "dn.se": ["nyheter", "ekonomi", "politik", "analys"],
        "1177.se": ["hälsa", "sjukvård", "medicin", "råd"]
    }

class SwedishSearchWorker(QThread):
    """Search worker thread - FIXED for your exact structure"""
    
    search_completed = pyqtSignal(list)
    search_progress = pyqtSignal(str)
    search_error = pyqtSignal(str)
    
    def __init__(self, query, domain_metadata):
        super().__init__()
        self.query = query
        self.domain_metadata = domain_metadata
        
        # Initialize systems
        try:
            # Revolutionary systems (if available)
            if REVOLUTIONARY_MODE:
                self.dossna = DOSSNA_2_Engine()
                self.asi = ASI_2_Index()
                print("✅ Revolutionary engines initialized")
            else:
                self.dossna = None
                self.asi = None
            
            # Your existing systems (always available)
            self.crawler = EnhancedSwedishCrawler(domain_metadata)  # ✅ CORRECT class name
            self.indexer = SuperFastBM25Indexer(
                trusted_domains=set(domain_metadata.keys()) if domain_metadata else set()
            )
            
        except Exception as e:
            print(f"⚠️ System init error: {e}")
            self.dossna = None
            self.asi = None
            # Fallback initialization
            self.crawler = EnhancedSwedishCrawler({})
            self.indexer = SuperFastBM25Indexer(set())
    
    def run(self):
        """Run search with hybrid revolutionary + enhanced approach"""
        
        try:
            start_time = time.time()
            
            # Step 1: Check for instant Swedish answers first (LOKI-style)
            self.search_progress.emit("🧠 Checking Swedish instant answers...")
            instant_answer = self._get_instant_swedish_answer()
            if instant_answer:
                result = [{
                    'title': '🇸🇪 Klar Direktsvar',
                    'url': '#instant',
                    'snippet': instant_answer,
                    'score': 1.0,
                    'source': 'swedish_knowledge_base',
                    'instant': True
                }]
                self.search_completed.emit(result)
                return
            
            # Step 2: Try revolutionary search (if available)
            if REVOLUTIONARY_MODE and self.dossna and self.asi:
                try:
                    self.search_progress.emit("🚀 DOSSNA 2.0 analyzing query...")
                    context = self.dossna.analyze_swedish_query(self.query)
                    
                    self.search_progress.emit(f"🎯 Intent: {context.intent} | Swedish: {context.swedish_confidence:.0%}")
                    
                    results = self.asi.revolutionary_search(self.query, context, limit=15)
                    
                    if results and len(results) > 0:
                        search_time = time.time() - start_time
                        metadata = {
                            'query': self.query,
                            'search_time': search_time,
                            'result_count': len(results),
                            'mode': 'revolutionary',
                            'algorithms': ['DOSSNA_2.0', 'ASI_2.0', 'SVEN', 'THOR', 'LOKI']
                        }
                        results.insert(0, {'metadata': metadata})
                        
                        self.search_progress.emit("✅ Revolutionary search completed!")
                        self.search_completed.emit(results)
                        return
                        
                except Exception as e:
                    print(f"Revolutionary search error: {e}")
                    self.search_progress.emit("⚠️ Revolutionary search failed, using enhanced...")
            
            # Step 3: Enhanced search with your existing system
            self.search_progress.emit("⚡ Enhanced Swedish search starting...")
            
            # Use your EnhancedSwedishCrawler
            seeds = asyncio.run(self.crawler.find_seeds(self.query))
            self.search_progress.emit(f"🔍 Found {len(seeds)} Swedish sources")
            
            if not seeds:
                self.search_error.emit("No relevant Swedish sources found")
                return
            
            # Crawl with your enhanced crawler
            pages = asyncio.run(self.crawler.crawl(seeds))
            self.search_progress.emit(f"📄 Successfully crawled {len(pages)} pages")
            
            if not pages:
                self.search_error.emit("No pages could be crawled")
                return
            
            # Index with your SuperFastBM25Indexer
            indexed_count = 0
            for url, html in pages.items():
                try:
                    title, snippet, text = parse_html(html)
                    if text and len(text.strip()) > 50:
                        self.indexer.add_document(url, title, snippet, text)
                        indexed_count += 1
                except Exception as e:
                    print(f"Parse error for {url}: {e}")
            
            self.search_progress.emit(f"📊 Indexed {indexed_count} documents")
            
            # Search with enhanced indexer
            results = self.indexer.enhanced_search(self.query, limit=15)
            
            # Add search metadata
            search_time = time.time() - start_time
            metadata = {
                'query': self.query,
                'search_time': search_time,
                'result_count': len(results),
                'pages_crawled': len(pages),
                'documents_indexed': indexed_count,
                'mode': 'enhanced',
                'algorithms': ['SuperFastBM25', 'EnhancedSwedishCrawler', 'Swedish_Optimization']
            }
            
            results.insert(0, {'metadata': metadata})
            
            self.search_progress.emit(f"✅ Found {len(results)-1} results in {search_time:.2f}s")
            self.search_completed.emit(results)
            
        except Exception as e:
            error_msg = f"Search error: {str(e)}"
            print(error_msg)
            self.search_error.emit(error_msg)
    
    def _get_instant_swedish_answer(self):
        """Get instant answers for common Swedish queries"""
        
        query_lower = self.query.lower()
        
        # Emergency numbers (highest priority)
        if any(term in query_lower for term in ['112', 'nödnummer', 'emergency', 'akut']):
            return "🚨 **Nödnummer Sverige: 112**\nPolis, Brandkår, Ambulans - Ring vid akuta situationer och livsfara"
        
        if any(term in query_lower for term in ['1177', 'sjukvårdsrådgivning', 'vårdråd']):
            return "🏥 **Sjukvårdsrådgivning: Ring 1177**\nDygnet runt för medicinska råd och hälsofrågor. Gratis från svenska telefonnummer."
        
        # Government contacts
        if any(term in query_lower for term in ['skatteverket', 'deklaration', 'skatt']):
            return "💰 **Skatteverket: 0771-567 567**\nskatteverket.se | Deklaration, moms, skattefrågor, preliminärskatt"
        
        if any(term in query_lower for term in ['försäkringskassan', 'sjukpenning', 'föräldrapenning']):
            return "💼 **Försäkringskassan: 0771-524 524**\nforsakringskassan.se | Sjukpenning, föräldrapenning, pension, barnbidrag"
        
        if any(term in query_lower for term in ['arbetsförmedlingen', 'jobb', 'arbetslöshet']):
            return "💼 **Arbetsförmedlingen: 0771-60 00 00**\narbetsformedlingen.se | Jobb, arbetslöshetsstöd, kompetensutveckling"
        
        if any(term in query_lower for term in ['polisen', 'brott', 'anmälan']):
            return "🚔 **Polisen: 114 14 (icke-akut)**\npolisen.se | Brottsanmälan, pass, körkort, ID-kort"
        
        # Swedish cultural concepts
        if 'allemansrätt' in query_lower:
            return "🌲 **Allemansrätt - Naturens Rättigheter**\nRätten att fritt röra sig i svensk natur. Grundregel: 'Inte störa, inte förstöra'. Tillåter camping, bärplockning, vandring."
        
        if 'fika' in query_lower:
            return "☕ **Fika - Svensk Kaffekultur**\nTraditionell svensk kaffepaus och viktig del av arbetsplatskulturen. Social samvaro och reflektion."
        
        if 'midsommar' in query_lower:
            return "🌸 **Midsommar - Sveriges Viktigaste Sommarfirande**\nFiras fredag mellan 19-25 juni. Midsommarstång, traditionell mat, sång och dans."
        
        # Basic Swedish facts
        if any(term in query_lower for term in ['befolkning', 'invånare', 'population']):
            return "🇸🇪 **Sveriges Befolkning**\n10.4 miljoner invånare (2023). Största städer: Stockholm (975k), Göteborg (580k), Malmö (350k)"
        
        if any(term in query_lower for term in ['huvudstad', 'capital']):
            return "🏛️ **Sveriges Huvudstad**\nStockholm - 975,000 invånare, belägen på 14 öar mellan Mälaren och Östersjön"
        
        return None

class BackendBridge(QObject):
    """Backend bridge - FIXED for your system"""
    
    sendResults = pyqtSignal(str)
    sendStatus = pyqtSignal(str)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        try:
            self.domain_metadata = load_domain_metadata()
            self.search_worker = None
            
            # Show active systems
            mode = "Revolutionary" if REVOLUTIONARY_MODE else "Enhanced"
            domain_count = len(self.domain_metadata)
            
            self.sendStatus.emit(f"🇸🇪 Klar 2.0 {mode} Ready! | {domain_count} Swedish domains loaded")
            
        except Exception as e:
            self.sendStatus.emit(f"⚠️ Initialization error: {e}")
            self.domain_metadata = {}
    
    @pyqtSlot(str)
    def search(self, query):
        """Main search function - FIXED"""
        
        if not query.strip():
            self.sendStatus.emit("❌ Ange en sökterm")
            return
        
        try:
            # Terminate previous search
            if self.search_worker and self.search_worker.isRunning():
                self.search_worker.terminate()
                self.search_worker.wait(2000)
            
            # Start new search
            self.sendStatus.emit(f"🔍 Söker: '{query}'...")
            
            self.search_worker = SwedishSearchWorker(query, self.domain_metadata)
            self.search_worker.search_completed.connect(self._on_results)
            self.search_worker.search_progress.connect(self._on_progress)
            self.search_worker.search_error.connect(self._on_error)
            self.search_worker.start()
            
        except Exception as e:
            self.sendStatus.emit(f"❌ Sökfel: {e}")
    
    def _on_results(self, results):
        """Handle search results"""
        try:
            self.sendResults.emit(json.dumps(results, ensure_ascii=False))
            
            # Update status with performance metrics
            if results and len(results) > 0 and isinstance(results[0], dict) and 'metadata' in results[0]:
                metadata = results[0]['metadata']
                count = metadata.get('result_count', len(results)-1)
                time_ms = metadata.get('search_time', 0) * 1000
                mode = metadata.get('mode', 'enhanced')
                
                self.sendStatus.emit(f"✅ {count} resultat på {time_ms:.0f}ms ({mode} mode)")
            else:
                self.sendStatus.emit(f"✅ Hittade {len(results)} resultat")
                
        except Exception as e:
            self.sendStatus.emit(f"❌ Resultatfel: {e}")
    
    def _on_progress(self, message):
        """Handle search progress"""
        self.sendStatus.emit(message)
    
    def _on_error(self, error):
        """Handle search errors"""
        self.sendStatus.emit(f"❌ Sökfel: {error}")
    
    @pyqtSlot(str)
    def open_url(self, url):
        """Open URL in browser"""
        try:
            if hasattr(self.parent(), 'browser'):
                self.parent().browser.load(QUrl(url))
        except Exception as e:
            self.sendStatus.emit(f"❌ URL-fel: {e}")

class KlarRevolutionaryBrowser(QMainWindow):
    """Klar 2.0 Revolutionary Browser - FIXED"""
    
    def __init__(self):
        super().__init__()
        
        # Setup window
        mode = "Revolution" if REVOLUTIONARY_MODE else "Enhanced" 
        self.setWindowTitle(f"🇸🇪 Klar 2.0 {mode} - Swedish Search Engine")
        self.resize(1400, 900)
        
        # Load icon
        try:
            icon_path = resource_path("icon.ico")
            if os.path.exists(icon_path):
                self.setWindowIcon(QIcon(icon_path))
        except:
            pass
        
        # Apply styling
        self._apply_swedish_styling()
        
        # Setup UI
        self._setup_interface()
        
        # Setup WebChannel bridge
        self._setup_webchannel()
        
        print(f"✅ Klar 2.0 {mode} Browser initialized with FIXED imports!")
    
    def _apply_swedish_styling(self):
        """Apply Swedish flag colors and styling"""
        
        self.setStyleSheet("""
        QMainWindow {
            background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,
                                      stop: 0 #1a1a1a, stop: 1 #2d2d2d);
            color: #ffffff;
        }
        
        QToolBar {
            background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,
                                      stop: 0 #0066CC, stop: 1 #004499);
            border: none;
            color: #ffffff;
            font-weight: bold;
            padding: 12px;
        }
        
        QToolBar QAction {
            background-color: rgba(255, 204, 0, 0.2);
            border: 2px solid #FFCC00;
            border-radius: 8px;
            padding: 12px 20px;
            margin: 4px;
            color: #ffffff;
            font-weight: bold;
            font-size: 14px;
        }
        
        QToolBar QAction:hover {
            background-color: rgba(255, 204, 0, 0.4);
            border-color: #FFDD11;
        }
        
        QStatusBar {
            background: #2d2d2d;
            color: #FFCC00;
            font-weight: bold;
            border-top: 3px solid #0066CC;
            padding: 10px;
            font-size: 14px;
        }
        
        QWebEngineView {
            border: 2px solid #0066CC;
            border-radius: 8px;
        }
        """)
    
    def _setup_interface(self):
        """Setup main interface"""
        
        # Browser view
        self.browser = QWebEngineView()
        page = self.browser.page()
        
        # Swedish browser settings
        settings = page.settings()
        settings.setAttribute(settings.JavascriptEnabled, True)
        settings.setAttribute(settings.AutoLoadImages, True)
        settings.setAttribute(settings.LocalContentCanAccessFileUrls, True)
        
        # Swedish language preferences
        profile = page.profile()
        profile.setHttpAcceptLanguage("sv-SE,sv;q=0.9,en;q=0.7")
        profile.setHttpUserAgent("Klar-2.0-Swedish-Search-Engine")
        
        self.setCentralWidget(self.browser)
        
        # Create toolbar
        self._create_toolbar()
        
        # Status bar
        self.status_bar = QStatusBar()
        mode = "Revolution" if REVOLUTIONARY_MODE else "Enhanced"
        self.status_bar.showMessage(f"🇸🇪 Klar 2.0 {mode} - Redo för svenska sökningar!")
        self.setStatusBar(self.status_bar)
        
        # Load home page
        self._load_home()
    
    def _create_toolbar(self):
        """Create Swedish-themed toolbar"""
        
        toolbar = QToolBar("Klar 2.0")
        toolbar.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        
        # Navigation
        back_action = QAction("⬅️ Tillbaka", self)
        back_action.setShortcut("Alt+Left")
        back_action.triggered.connect(self.browser.back)
        toolbar.addAction(back_action)
        
        forward_action = QAction("➡️ Framåt", self)
        forward_action.setShortcut("Alt+Right")
        forward_action.triggered.connect(self.browser.forward)
        toolbar.addAction(forward_action)
        
        reload_action = QAction("🔄 Ladda Om", self)
        reload_action.setShortcut("F5")
        reload_action.triggered.connect(self.browser.reload)
        toolbar.addAction(reload_action)
        
        toolbar.addSeparator()
        
        # Swedish shortcuts
        home_action = QAction("🏠 Hem", self)
        home_action.triggered.connect(self._load_home)
        toolbar.addAction(home_action)
        
        gov_action = QAction("🏛️ Regeringen", self)
        gov_action.triggered.connect(lambda: self.browser.load(QUrl("https://regeringen.se")))
        toolbar.addAction(gov_action)
        
        news_action = QAction("📰 SVT", self)
        news_action.triggered.connect(lambda: self.browser.load(QUrl("https://svt.se/nyheter")))
        toolbar.addAction(news_action)
        
        # Mode indicator
        mode_text = "🚀 Revolution" if REVOLUTIONARY_MODE else "⚡ Enhanced"
        mode_action = QAction(mode_text, self)
        mode_action.triggered.connect(self._show_mode_info)
        toolbar.addAction(mode_action)
        
        self.addToolBar(toolbar)
    
    def _setup_webchannel(self):
        """Setup WebChannel for frontend-backend communication"""
        
        try:
            self.channel = QWebChannel()
            self.browser.page().setWebChannel(self.channel)
            
            self.bridge = BackendBridge(self)
            self.bridge.sendStatus.connect(self._update_status)
            self.channel.registerObject("backend", self.bridge)
            
            print("✅ WebChannel bridge setup complete")
            
        except Exception as e:
            print(f"⚠️ WebChannel setup error: {e}")
    
    def _load_home(self):
        """Load Klar home page"""
        
        # Try to use existing template
        templates_path = os.path.join(os.path.dirname(__file__), "templates")
        index_file = os.path.join(templates_path, "index.html")
        
        if os.path.exists(index_file):
            self.browser.load(QUrl.fromLocalFile(index_file))
            print("✅ Using existing templates/index.html")
        else:
            print("⚡ Loading built-in revolutionary home page")
            self._load_builtin_home()
    
    def _load_builtin_home(self):
        """Load built-in Swedish home page"""
        
        mode = "Revolution" if REVOLUTIONARY_MODE else "Enhanced"
        
        home_html = f'''<!DOCTYPE html>
<html lang="sv">
<head>
    <meta charset="UTF-8">
    <title>Klar 2.0 {mode}</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            background: linear-gradient(135deg, #0066CC 0%, #1a1a1a 50%, #FFCC00 100%);
            font-family: 'Segoe UI', Arial, sans-serif;
            color: white;
            min-height: 100vh;
        }}
        .container {{
            max-width: 900px;
            margin: 0 auto;
            padding: 40px 20px;
            text-align: center;
        }}
        .logo {{
            font-size: 4em;
            font-weight: bold;
            margin-bottom: 20px;
            text-shadow: 2px 2px 8px rgba(0,0,0,0.7);
        }}
        .mode {{
            display: inline-block;
            background: rgba(255,204,0,0.3);
            padding: 8px 20px;
            border-radius: 20px;
            border: 2px solid #FFCC00;
            margin: 20px 0;
            font-weight: bold;
        }}
        .search-box {{
            display: flex;
            background: rgba(255,255,255,0.9);
            border-radius: 50px;
            padding: 8px;
            margin: 30px 0;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        }}
        .search-input {{
            flex: 1;
            border: none;
            padding: 15px 25px;
            font-size: 18px;
            border-radius: 45px;
            outline: none;
            color: #333;
        }}
        .search-button {{
            background: linear-gradient(45deg, #0066CC, #FFCC00);
            border: none;
            padding: 15px 25px;
            border-radius: 45px;
            color: white;
            font-weight: bold;
            cursor: pointer;
        }}
        .quick-links {{
            margin: 30px 0;
        }}
        .quick-link {{
            display: inline-block;
            background: rgba(0,102,204,0.2);
            color: white;
            padding: 10px 15px;
            margin: 5px;
            border-radius: 15px;
            text-decoration: none;
            border: 1px solid #0066CC;
            cursor: pointer;
        }}
        .quick-link:hover {{
            background: rgba(0,102,204,0.4);
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">🇸🇪 KLAR 2.0</div>
        <div class="mode">{mode} MODE</div>
        <p style="font-size: 1.2em; margin: 20px 0;">
            Sveriges kraftfullaste sökmotorn med {'revolutionära algoritmer' if REVOLUTIONARY_MODE else 'förbättrade algoritmer'}
        </p>
        
        <div class="search-box">
            <input type="text" class="search-input" id="searchInput" 
                   placeholder="Sök på svenska webbplatser..."
                   onkeypress="if(event.key==='Enter') performSearch()">
            <button class="search-button" onclick="performSearch()">
                🔍 Sök
            </button>
        </div>
        
        <div class="quick-links">
            <strong>Snabbsökning:</strong><br><br>
            <div class="quick-link" onclick="quickSearch('svenska nyheter')">📰 Nyheter</div>
            <div class="quick-link" onclick="quickSearch('skatteverket')">💰 Skatteverket</div>
            <div class="quick-link" onclick="quickSearch('112')">🚨 Nödnummer</div>
            <div class="quick-link" onclick="quickSearch('köpa bil')">🚗 Köpa bil</div>
            <div class="quick-link" onclick="quickSearch('1177')">🏥 Hälsa</div>
            <div class="quick-link" onclick="quickSearch('allemansrätt')">🌲 Allemansrätt</div>
        </div>
        
        <div style="margin-top: 40px; font-size: 0.9em; opacity: 0.8;">
            {'🚀 DOSSNA 2.0 | ASI 2.0 | SVEN | THOR | LOKI' if REVOLUTIONARY_MODE else '⚡ SuperFast BM25 | Enhanced Swedish Crawler | Swedish Optimization'}
        </div>
    </div>
    
    <script>
        function performSearch() {{
            const query = document.getElementById('searchInput').value.trim();
            if (query && window.backend) {{
                window.backend.search(query);
            }}
        }}
        
        function quickSearch(query) {{
            document.getElementById('searchInput').value = query;
            performSearch();
        }}
        
        // WebChannel initialization
        if (typeof qt !== 'undefined' && qt.webChannelTransport) {{
            new QWebChannel(qt.webChannelTransport, function(channel) {{
                window.backend = channel.objects.backend;
                console.log('🇸🇪 Klar WebChannel ready!');
            }});
        }}
    </script>
</body>
</html>'''
        
        self.browser.setHtml(home_html)
    
    def _show_mode_info(self):
        """Show current mode information"""
        
        if REVOLUTIONARY_MODE:
            info_html = """
            <h2 style="color: #FFCC00;">🚀 Revolutionary Mode</h2>
            <div style="background: #2d4a2d; padding: 20px; border-radius: 10px; margin: 15px 0;">
                <h3 style="color: #4CAF50;">Aktiva revolutionära algoritmer:</h3>
                <ul style="line-height: 1.8;">
                    <li><strong>DOSSNA 2.0</strong> - Svensk sökalgoritm med kulturell intelligens</li>
                    <li><strong>ASI 2.0</strong> - Avancerad sökindex med P2P</li>
                    <li><strong>SVEN</strong> - Svenska semantiska vektornätverk</li>
                    <li><strong>THOR</strong> - Svenskt förtroenderanking</li>
                    <li><strong>LOKI</strong> - Offline svensk kunskapsbas</li>
                    <li><strong>SuperFast BM25</strong> - Förbättrad indexering</li>
                    <li><strong>EnhancedSwedishCrawler</strong> - Multi-domän crawler</li>
                </ul>
            </div>
            <p><strong>Målprestanda:</strong> Sub-100ms svenska sökningar med kulturell förståelse</p>
            """
        else:
            info_html = """
            <h2 style="color: #FFCC00;">⚡ Enhanced Mode</h2>
            <div style="background: #4a4a2d; padding: 20px; border-radius: 10px; margin: 15px 0;">
                <h3 style="color: #FFC107;">Aktiva förbättrade system:</h3>
                <ul style="line-height: 1.8;">
                    <li><strong>SuperFast BM25</strong> - Din 15k-raders förbättrade indexer</li>
                    <li><strong>EnhancedSwedishCrawler</strong> - Multi-domän svensk crawler</li>
                    <li><strong>Swedish Optimization</strong> - Kulturell förstärkning & synonymer</li>
                    <li><strong>Instant Answers</strong> - Svensk myndighets- och kulturell kunskap</li>
                    <li><strong>Authority Boosting</strong> - Prioriterar svenska myndigheter</li>
                </ul>
            </div>
            <p><strong>Prestanda:</strong> Snabb svensk sökning med beprövade algoritmer</p>
            """
        
        self.browser.setHtml(f"""
        <!DOCTYPE html>
        <html lang="sv">
        <head>
            <meta charset="UTF-8">
            <style>
                body {{ background: #1a1a1a; color: white; font-family: Arial; padding: 30px; }}
                h2 {{ text-align: center; margin-bottom: 20px; }}
                ul {{ margin: 15px 0; padding-left: 20px; }}
                li {{ margin: 8px 0; }}
                p {{ text-align: center; margin: 20px 0; font-size: 1.1em; }}
            </style>
        </head>
        <body>
            {info_html}
            <div style="text-align: center; margin-top: 30px;">
                <button onclick="window.history.back()" 
                        style="background: #0066CC; color: white; border: none; padding: 15px 25px; 
                               border-radius: 20px; font-size: 16px; cursor: pointer;">
                    ⬅️ Tillbaka
                </button>
            </div>
        </body>
        </html>
        """)
    
    def _update_status(self, message):
        """Update status bar"""
        self.status_bar.showMessage(message)
    
def main():
    """Main entry point - FIXED"""
    
    mode = "Revolution" if REVOLUTIONARY_MODE else "Enhanced"
    print(f"🇸🇪 Starting Klar 2.0 {mode}...")
    print("🔧 Using EnhancedSwedishCrawler + SuperFastBM25Indexer")
    
    try:
        # Create Qt application
        app = QApplication(sys.argv)
        app.setApplicationName(f"Klar 2.0 {mode}")
        app.setApplicationVersion("2.0.0")
        
        # Swedish locale
        from PyQt5.QtCore import QLocale
        QLocale.setDefault(QLocale(QLocale.Swedish, QLocale.Sweden))
        
        # Create browser
        browser = KlarRevolutionaryBrowser()
        browser.show()
        
        # Setup async event loop for crawler compatibility
        loop = QEventLoop(app)
        asyncio.set_event_loop(loop)
        
        print(f"✅ Klar 2.0 {mode} ready with FIXED imports!")
        
        with loop:
            return loop.run_forever()
            
    except Exception as e:
        print(f"❌ Startup error: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(main())